package com.example.labour.serviceImpl;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.data.Exception.LabourNotFoundException;
import com.example.data.Repository.LabourRepository;
import com.example.data.entity.Labour;
import com.example.labour.service.LabourService;

@Service
public class LabourServiceImpl implements LabourService{
	
	@Autowired
	LabourRepository labourRepository;
	

	@Override
	public Labour saveLabourDetails(Labour labour) {
		Labour lab=new Labour();
		try {
			if(!Objects.isNull(labour)) {
				lab=Labour.builder()
						.labName(labour.getLabName())
						.location(labour.getLocation())
						.experience(labour.getExperience())
						.amountPerDay(labour.getAmountPerDay())
						.filedNum(labour.getFiledNum())
						.field(labour.getField())
						.mobileNum(labour.getMobileNum())
						.build();
				
			}
		}
		catch(LabourNotFoundException e) {
			throw e;
		}
		 return labourRepository.save(lab);
	}


	@Override
	public List<Labour> getAllLabour() {
		labourRepository.
		return null;
	}

}
