package com.example.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.data.entity.Labour;
import com.example.data.entity.User;
import com.example.data.entity.UserRequest;

@Service
public interface UserService {

	User saveUserDetails(User user);

	List<Labour> getLabourDetails(String filed, String amountPerDay) throws Exception;

	UserRequest requestforWork(UserRequest userRequest) throws Exception;

}
