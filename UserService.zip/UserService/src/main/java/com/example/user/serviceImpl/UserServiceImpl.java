package com.example.user.serviceImpl;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.example.data.Exception.UserNotFoundException;
import com.example.data.Repository.LabourRepository;
import com.example.data.Repository.UserRepository;
import com.example.data.Repository.UserRequestRepository;
import com.example.data.entity.Labour;
import com.example.data.entity.User;
import com.example.data.entity.UserRequest;
import com.example.user.service.UserService;



@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	LabourRepository labourRepository;
	
	@Autowired
	UserRequestRepository userRequestRepository;

	@Override
	public User saveUserDetails(User userDetails) {
		try {
		User user=new User();
		if (!Objects.isNull(userDetails)) {

			user=User.builder()
					.userName(userDetails.getUserName())
					.address(userDetails.getAddress())
					.mobilNum(userDetails.getMobilNum())
					.build();
		}
		return userRepository.save(user);
		}
		catch(UserNotFoundException e) {
			throw e;
		}
		
	}

	@Override
	public List<Labour> getLabourDetails(String field, String amountPerDay) throws Exception {
		List<Labour> LabourDetails=null;
		try{
			if(Objects.nonNull(field) && !StringUtils.isEmpty(amountPerDay)) {
			 LabourDetails=labourRepository.findByFieldAndAmountPerDay(field,amountPerDay);
			return LabourDetails;
			}
			else if(Objects.nonNull(field)) {
				 LabourDetails=labourRepository.findByField(field);
				 return LabourDetails;
			}
		}
		catch(Exception e){
			throw new Exception("Invalid Input!!!");
		}
		 return LabourDetails;
	}

	@Override
	public UserRequest requestforWork(UserRequest userRequest) throws Exception {
		try {
		UserRequest request=null;
		if(Objects.nonNull(userRequest)) {
			request=UserRequest.builder()
					.userId(userRequest.getUserId())
					.labId(userRequest.getLabId())
					.field(userRequest.getField())
					.moilNum(userRequest.getMoilNum())
					.build();
		}
		return userRequestRepository.save(request);
		}
		catch(Exception e) {
			throw new Exception("Invalid Request!!!");
		}
	}

}
